//
//  AppDelegate.h
//  LateralSpreadsDemo
//
//  Created by Huarui IoT on 2018/2/27.
//  Copyright © 2018年 Huarui IoT. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMDrawerController.h"
#import "MMExampleDrawerVisualStateManager.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic ,strong) MMDrawerController *drawerController ;


@end

